package package4;

public interface DigitTV {
	public void changeChanel();
}
