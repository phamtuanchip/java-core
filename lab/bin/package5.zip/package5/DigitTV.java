package package5;

public interface DigitTV {
	public void changeChanel();
}
