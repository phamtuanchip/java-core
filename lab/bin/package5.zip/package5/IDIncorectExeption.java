package package5;

public class IDIncorectExeption extends Exception {
public String getMessage(){
	return "Id have 6 digit numer!";
}
}
