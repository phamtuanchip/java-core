package package5;

public class IDLengthIncorectExeption extends Exception {
public String getMessage(){
	return "Id have 6 char log!";
}
}
