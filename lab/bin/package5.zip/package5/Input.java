package package5;

import java.util.Scanner;

public class Input {
	public static int insertId() throws IDLengthIncorectExeption, IDIncorectExeption {
		System.out.println("In sert id:");
		Scanner si = new Scanner(System.in);
		String s = si.nextLine();
		int id = 0;
		if(s == null || s.length() != 6) throw new IDLengthIncorectExeption();
		try {		
			id = Integer.parseInt(s);
		} catch (NumberFormatException e) {
			throw new IDIncorectExeption();
		}
		return id;
		
	}
	public static String insertUserName() throws NameIncorectExeption{
		System.out.println("Insert Name:");
		Scanner si = new Scanner(System.in);
		String name = si.nextLine();
		if(name == null || name.isEmpty()) throw new NameIncorectExeption();
		return name;
	}
	
}
