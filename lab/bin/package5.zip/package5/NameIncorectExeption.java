package package5;

public class NameIncorectExeption extends Exception {
	public String getMessage(){
		return "Name is required!";
	}
}
