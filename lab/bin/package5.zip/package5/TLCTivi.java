package package5;

public class TLCTivi implements TV, DigitTV {

	@Override
	public void changeChanel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void volumUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void volumDown() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeContrast() {
		// TODO Auto-generated method stub
		
	}

}
