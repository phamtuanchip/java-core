package final_exam;

public class BaseSalaryException extends Exception {
	public String getMessage(){
		return "Salary is not lower base salary 3100 000!";
	}

}
