package final_exam;

public class DataInputExeption extends Exception {
	public String getMessage(){
		return "Input is required!";
	}

}
