package final_exam;

import java.util.Date;

public interface Human {
	public void setName(String name);
	public String getName();
	public void setDateOfBirth(Date date);
	public Date getDateOfBirth();
	public void setPlaceOfBirth(String place);
	public String getPlaceOfBirth();
}
