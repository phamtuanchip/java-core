package final_exam;

public class IDIncorectExeption extends Exception {
public String getMessage(){
	return "Id have 6 digit numer!";
}
}
