package final_exam;

public abstract class People {
	int id;
	public abstract void setId(int id);
	public int getId(){return id;}
}
