package package3;

public class Car {
	String Model = "";
	String Color = "";
	String Brand = "";
	
	String getModel() {		
		
		return Model;
	}
	
	String getColor() {
		
		return Color;
	}
	
	String getBrand() {
		
		return Brand;
	}
	
	void setModel(String n) {
		// Set Model here
	}
	
	void setColor(String d) {
		// Set Color here
	}
	
	void setBrand(String h) {
		// Set Brand here
	}
}
