package package3;

public interface DigitTV {
	public void changeChanel();
}
