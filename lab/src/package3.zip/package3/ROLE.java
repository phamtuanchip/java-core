package package3;

class ROLE {
 public static String role_PM = "PM";
 public static String role_TL = "TL";
 public static String role_PL = "PL";
 public static String role_QA = "QA";
}