package package3;

public interface TV {
	public void volumUp();
	public void volumDown();
	public void changeContrast();
}
